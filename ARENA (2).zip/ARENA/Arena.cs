﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ARENA
{
    public class Arena
    {
        public List<Gladiatore> Gladiatori { get; private set; }
        private Random random = new Random();

        public Arena()
        {
            Gladiatori = new List<Gladiatore>();
            for (int i = 0; i < 10; i++)
            {
                Gladiatori.Add(new Gladiatore(i + 1));
            }
        }

        public bool CiSonoGladiatoriVivi()
        {
            int gladiatoriVivi = 0;
            foreach (var g in Gladiatori)
            {
                if (g.IsVivo())
                    gladiatoriVivi++;
                if (gladiatoriVivi >= 2)
                    return true;
            }
            return false;
        }

        public void EseguiCombattimento(TextBox txtLog)
        {
            var attaccante = TrovaGladiatoreVivo();
            var difensore = TrovaGladiatoreVivo();

            while (difensore == attaccante)
            {
                difensore = TrovaGladiatoreVivo();
            }

            AggiornaLog(txtLog, $"Sono stati scelti {attaccante.Nome} e {difensore.Nome} per la prossima partita.");
            AggiornaLog(txtLog, $"{attaccante.Nome} (PF: {attaccante.PuntiFerita}) vs {difensore.Nome} (PF: {difensore.PuntiFerita})");

            while (attaccante.IsVivo() && difensore.IsVivo())
            {
                attaccante.Attacca(difensore);
                AggiornaLog(txtLog, $"{attaccante.Nome} attacca {difensore.Nome}. {difensore.Nome} ha {difensore.PuntiFerita} PF rimanenti.");

                if (difensore.IsVivo())
                {
                    difensore.Attacca(attaccante);
                    AggiornaLog(txtLog, $"{difensore.Nome} contrattacca {attaccante.Nome}. {attaccante.Nome} ha {attaccante.PuntiFerita} PF rimanenti.");
                }
            }

            if (!attaccante.IsVivo() && !difensore.IsVivo())
            {
                if (random.Next(2) == 0)
                {
                    attaccante.RecuperaVita();
                    Gladiatori.Remove(difensore);
                    AggiornaLog(txtLog, $"{attaccante.Nome} vince il combattimento e recupera tutta la vita! {attaccante.Nome} ritorna nel gruppo.");
                }
                else
                {
                    difensore.RecuperaVita();
                    Gladiatori.Remove(attaccante);
                    AggiornaLog(txtLog, $"{difensore.Nome} vince il combattimento e recupera tutta la vita! {difensore.Nome} ritorna nel gruppo.");
                }
            }
            else if (!attaccante.IsVivo())
            {
                difensore.RecuperaVita();
                Gladiatori.Remove(attaccante);
                AggiornaLog(txtLog, $"{difensore.Nome} vince il combattimento e recupera tutta la vita! {difensore.Nome} ritorna nel gruppo.");
            }
            else if (!difensore.IsVivo())
            {
                attaccante.RecuperaVita();
                Gladiatori.Remove(difensore);
                AggiornaLog(txtLog, $"{attaccante.Nome} vince il combattimento e recupera tutta la vita! {attaccante.Nome} ritorna nel gruppo.");
            }
        }

        private Gladiatore TrovaGladiatoreVivo()
        {
            List<Gladiatore> gladiatoriVivi = new List<Gladiatore>();
            foreach (var g in Gladiatori)
            {
                if (g.IsVivo())
                    gladiatoriVivi.Add(g);
            }
            return gladiatoriVivi[random.Next(gladiatoriVivi.Count)];
        }

        private void AggiornaLog(TextBox txtLog, string messaggio)
        {
            if (txtLog.IsDisposed || txtLog.Disposing)
            {
                return;
            }

            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action<TextBox, string>(AggiornaLog), txtLog, messaggio);
            }
            else
            {
                txtLog.AppendText(messaggio + Environment.NewLine);
            }
        }
    }
}