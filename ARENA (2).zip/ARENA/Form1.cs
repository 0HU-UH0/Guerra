using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ARENA
{
    public partial class Form1 : Form
    {
        private Arena arena;

        public Form1()
        {
            InitializeComponent(); 
            arena = new Arena();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false; 

           
            {
                Combatti();

                if (!this.IsDisposed)
                {
                    this.Invoke(new Action(() => btnStart.Enabled = true));
                }
            };
        }

        private void Combatti()
        {         
            while (arena.CiSonoGladiatoriVivi() && !this.IsDisposed)
            {
                arena.EseguiCombattimento(txtLog); 
                Application.DoEvents(); 

                if (this.IsDisposed)
                {
                    break;
                }

                System.Threading.Thread.Sleep(1000);
            }

            if (!this.IsDisposed)
            {
                AggiornaLog(txtLog, "Tutti i combattimenti sono terminati!\r\n");
                if (arena.Gladiatori.Count == 1)
                {
                    AggiornaLog(txtLog, $"{arena.Gladiatori[0].Nome} � il vincitore assoluto!\r\n");
                }
            }
        }

        private void AggiornaLog(TextBox txtLog, string messaggio)
        {
            if (txtLog.IsDisposed || txtLog.Disposing)
            {
                return;
            }

            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action<TextBox, string>(AggiornaLog), txtLog, messaggio);
            }
            else
            {
                txtLog.AppendText(messaggio + Environment.NewLine);
            }
        }
    }
}